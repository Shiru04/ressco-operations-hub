import React, { useRef } from "react";
import { Box, Card, CardContent, Chip, Typography } from "@mui/material";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

function measurementsToText(m) {
  const entries = Object.entries(m || {})
    .filter(([, v]) => v !== null && v !== undefined && String(v).trim() !== "")
    .slice(0, 8)
    .map(([k, v]) => `${k}:${v}`);
  return entries.join("  ");
}

export default function PieceCard({ piece, onOpen, disableDnd = false }) {
  const justDraggedRef = useRef(false);

  // Always call the hook (no conditional hooks)
  const sortable = useSortable({ id: piece.id });

  const style = disableDnd
    ? { opacity: 1 }
    : {
        transform: CSS.Transform.toString(sortable.transform),
        transition: sortable.transition,
        opacity: sortable.isDragging ? 0.75 : 1,
      };

  return (
    <Card
      ref={disableDnd ? null : sortable.setNodeRef}
      style={style}
      variant="outlined"
      sx={{ pointerEvents: disableDnd ? "none" : "auto" }}
    >
      <CardContent
        onClick={() => {
          if (disableDnd) return;
          if (justDraggedRef.current) return;
          onOpen?.(piece);
        }}
        sx={{
          display: "grid",
          gap: 0.75,
          p: 1.25,
          cursor: disableDnd ? "default" : "pointer",
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 1,
          }}
        >
          <Typography sx={{ fontWeight: 900 }}>
            #{piece.lineNo} {piece.typeCode}
          </Typography>
          <Chip size="small" label={`qty ${piece.qty}`} />
        </Box>

        <Typography variant="body2" sx={{ opacity: 0.8 }}>
          {measurementsToText(piece.measurements) || "—"}
        </Typography>

        {piece.ga ? (
          <Typography variant="caption" sx={{ opacity: 0.75 }}>
            GA: {piece.ga}
          </Typography>
        ) : null}

        {piece.remarks ? (
          <Typography variant="caption" sx={{ opacity: 0.75 }}>
            {piece.remarks}
          </Typography>
        ) : null}

        {!disableDnd ? (
          <Box
            ref={sortable.setActivatorNodeRef}
            {...sortable.attributes}
            {...sortable.listeners}
            onPointerDown={(e) => {
              justDraggedRef.current = true;
              setTimeout(() => (justDraggedRef.current = false), 250);
              e.stopPropagation();
            }}
            onClick={(e) => e.stopPropagation()}
            sx={{
              mt: 0.5,
              p: 0.6,
              borderRadius: 1,
              bgcolor: "rgba(255,255,255,0.04)",
              textAlign: "center",
              fontSize: 12,
              opacity: 0.85,
              userSelect: "none",
              cursor: "grab",
            }}
          >
            Drag
          </Box>
        ) : null}
      </CardContent>
    </Card>
  );
}
